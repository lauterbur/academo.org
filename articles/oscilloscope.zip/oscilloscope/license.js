/*
+---------------------------------------------------------+
| Edward Ball, Frances Ruiz, and Michael Ruiz             |
+---------------------------------------------------------|
| License:                                                |
| Creative Commons Attribution-NonCommerial 4.0 Unported  |
| http://creativecommons.org/licenses/by-nc/4.0/legalcode |
+---------------------------------------------------------+
| You are free to (for noncommercial use):                |
|                                                         |
| Share � copy and redistribute the material in any       |
|         medium or format                                |
| Adapt � remix, transform, and build upon the material   |
|                                                         |
| The licensor cannot revoke these freedoms as long as    |
| you follow the license terms.                           |
|                                                         |
| Attribution � You must give appropriate credit, include |
| this license, and indicate if changes were made. You    |
| may do so in any reasonable manner, but not in any way  |
| that suggests the licensor endorses you or your use.    |
|                                                         |
| Sample Web Credit Line:                                 |
|    Courtesy Edward Ball, Frances and Michael Ruiz       |
|                                                         |
| NonCommercial � You may not use the material for        |
|   commercial purposes.                                  |
|                                                         |
| No additional restrictions � You may not apply legal    |
| terms or technological measures that legally restrict   |
| others from doing anything the license permits.         |
+---------------------------------------------------------+
*/
